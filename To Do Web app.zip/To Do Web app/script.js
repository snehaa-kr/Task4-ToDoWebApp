const taskText = document.getElementById('taskText');
const taskDate = document.getElementById('taskDate');
const addTaskButton = document.getElementById('addTaskButton');
const taskList = document.getElementById('taskList');

addTaskButton.addEventListener('click', addTask);

function addTask() {
    const text = taskText.value.trim();
    const date = taskDate.value;

    if (!text || !date) {
        alert("Please fill in both the task and the date/time.");
        return;
    }

    const taskItem = document.createElement('li');
    taskItem.classList.add('task-item');

    const taskContent = document.createElement('span');
    taskContent.textContent = `${text} (Due: ${new Date(date).toLocaleString()})`;

    const actionsDiv = document.createElement('div');
    actionsDiv.classList.add('actions');

    const completeButton = document.createElement('button');
    completeButton.textContent = 'Complete';
    completeButton.classList.add('complete');
    completeButton.addEventListener('click', () => {
        taskItem.classList.toggle('completed');
    });

    const editButton = document.createElement('button');
    editButton.textContent = 'Edit';
    editButton.classList.add('edit');
    editButton.addEventListener('click', () => {
        const newText = prompt("Edit your task:", text);
        const newDate = prompt("Edit the due date (YYYY-MM-DDTHH:MM):", date);
        if (newText && newDate) {
            taskContent.textContent = `${newText.trim()} (Due: ${new Date(newDate).toLocaleString()})`;
        }
    });

    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.classList.add('delete');
    deleteButton.addEventListener('click', () => {
        if (confirm("Are you sure you want to delete this task?")) {
            taskList.removeChild(taskItem);
        }
    });

    actionsDiv.appendChild(completeButton);
    actionsDiv.appendChild(editButton);
    actionsDiv.appendChild(deleteButton);

    taskItem.appendChild(taskContent);
    taskItem.appendChild(actionsDiv);

    taskList.appendChild(taskItem);

    taskText.value = '';
    taskDate.value = '';
}
